import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
export { React, Slot } // minimal placeholder for ZIP