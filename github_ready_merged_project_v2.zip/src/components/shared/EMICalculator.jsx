import React, { useState, useMemo } from 'react';

export default function EMICalculator() {
  const [principal, setPrincipal] = useState(500000);
  const [rate, setRate] = useState(14);
  const [tenure, setTenure] = useState(36);

  const { emi } = useMemo(() => {
    const monthlyRate = rate / 100 / 12;
    const emi =
      (principal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) /
      (Math.pow(1 + monthlyRate, tenure) - 1);
    return { emi };
  }, [principal, rate, tenure]);

  return <div>EMI: {emi.toFixed(0)}</div>;
}
