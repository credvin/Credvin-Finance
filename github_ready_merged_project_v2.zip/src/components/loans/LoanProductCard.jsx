import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function LoanProductCard({ loan, index }) {
  const Icon = loan.icon;
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }}>
      <Card className="border-0 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden">
        <CardContent className="p-0">
          <div className={`h-2 bg-gradient-to-r ${loan.gradient}`} />
          <div className="p-8">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-14 h-14 rounded-2xl ${loan.iconBg} flex items-center justify-center`}>
                {Icon && <Icon className={`w-7 h-7 ${loan.iconColor}`} />}
              </div>
              <Badge variant="secondary" className="text-xs">{loan.badge}</Badge>
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-2">{loan.title}</h3>
            <p className="text-muted-foreground leading-relaxed mb-6">{loan.description}</p>
            <Link to={createPageUrl('ApplyLoan') + `?type=${loan.type}`}>
              <Button className="w-full">Apply</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
